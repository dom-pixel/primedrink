<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">Informações da distribuidora/empório '<?php echo e($restaurant->trading_name); ?>'</div>
                    <div class="card-body">
                        <a class="btn btn-link" href="<?php echo e(route('home')); ?>">
                            Voltar
                        </a>
                        <b><p class="text-dark">Informações da Distribuidora/Empório:</p></b>
                        <p>Razão Social: <?php echo e($restaurant->company_name); ?></p>
                        <p>Fantasia: <?php echo e($restaurant->trading_name); ?></p>
                        <p>CNPJ: <?php echo e($restaurant->cnpj); ?></p>
                        <p>Telefone:<?php echo e($restaurant->phone); ?> </p>
                        <p>Endereço: <?php echo e($restaurant->street); ?>, Nº<?php echo e($restaurant->number); ?>,
                            Bairro <?php echo e($restaurant->neighborhood); ?>, <?php echo e($restaurant->complement); ?>, <?php echo e($restaurant->city); ?>

                            /<?php echo e($restaurant->state); ?>, <?php echo e($restaurant->zipcode); ?></p>
                        <p>Especialidade: <?php echo e($restaurant->business); ?></p>
                        <p>Possui delivery: <?php echo e(($restaurant->delivery === 1 ? 'Sim' : 'Não')); ?></p>
                        <b><p class="text-dark">Informações do Dono:</p></b>
                        <p>Nome Completo: <?php echo e($restaurant->full_name); ?></p>
                        <p>CPF: <?php echo e($restaurant->document); ?></p>
                        <p>RG: <?php echo e($restaurant->document_secondary); ?>

                            / <?php echo e($restaurant->document_secondary_complement); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/bitnami/apache2/htdocs/bohemia/resources/views/restaurant.blade.php ENDPATH**/ ?>