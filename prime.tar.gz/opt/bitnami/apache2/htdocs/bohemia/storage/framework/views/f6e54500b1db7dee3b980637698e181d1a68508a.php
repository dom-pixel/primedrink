<?php echo e($slot); ?>

<?php /**PATH /opt/bitnami/apache2/htdocs/bohemia/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>