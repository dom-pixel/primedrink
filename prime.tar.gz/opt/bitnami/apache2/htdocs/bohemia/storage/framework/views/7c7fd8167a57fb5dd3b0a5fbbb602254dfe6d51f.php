<?php $__env->startComponent('mail::message'); ?>
    <h1>Pré-inscrição feita com sucesso!</h1>
    <p> Olá, <?php echo e($name); ?>. tudo prime? 😉</p>
    <p>Estamos felizes em seu interesse em se credenciar na Prime Drink.
        Recebemos todas as suas informações com sucesso! 🍻
    </p>
    <p>Agora é só aguardar um de nossos especialistas entrar em contato com você e finalizar seu credenciamento! </p>
    *E-mail enviado automático através do sistema.
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /opt/bitnami/apache2/htdocs/bohemia/resources/views/mail/register.blade.php ENDPATH**/ ?>