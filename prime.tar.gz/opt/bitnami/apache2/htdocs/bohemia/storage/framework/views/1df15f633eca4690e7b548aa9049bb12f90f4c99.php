<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header">Informações do '<?php echo e($subscription->name); ?>'</div>
                    <div class="card-body">
                        <a class="btn btn-link" href="<?php echo e(route('home')); ?>">
                            Voltar
                        </a>
                        <b><p class="text-dark">Informações do interessado em ser sócio Prime:</p></b>
                        <p>Nome Completo: <?php echo e($subscription->name); ?> <?php echo e($subscription->surname); ?></p>
                        <p>Telefone:<?php echo e($subscription->cell); ?> </p>
                        <p>E-mail: <?php echo e($subscription->email); ?></p>
                        <p>Cidade e Estado: <?php echo e($subscription->city); ?>/<?php echo e($subscription->state); ?></p>
                        <p>Cidade de interesse: <?php echo e($subscription->city_of_interest); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/bitnami/apache2/htdocs/bohemia/resources/views/partner.blade.php ENDPATH**/ ?>