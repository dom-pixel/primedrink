[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /opt/bitnami/apache2/htdocs/bohemia/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>