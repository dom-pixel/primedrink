<?php echo $__env->yieldContent('script'); ?>
<!-- JS -->
<script src="<?php echo e(asset('front/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('front/retina.js')); ?>"></script>
<script src="<?php echo e(asset('front/parallax.js')); ?>"></script>
<script src="<?php echo e(asset('front/wow.js')); ?>"></script>
<script src="<?php echo e(asset('front/carousel.js')); ?>"></script>
<script src="<?php echo e(asset('front/custom.js')); ?>"></script>
<!-- SLIDER REV -->
<script src="<?php echo e(asset('front/jquery.themepunch.tools.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/jquery.themepunch.revolution.min.js')); ?>"></script>
<script src="<?php echo e(asset('front/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(asset('front/jquery-ui-timepicker-addon.js')); ?>"></script>
<script src="<?php echo e(asset('front/bootstrap-select.js')); ?>"></script>
<script type="text/javascript">
    function openNav() {
        document.getElementById("mySidenav").style.width = "185px";
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
    }
</script>
<!-- scripts customizados -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.0/jquery.mask.js"></script>
<!-- scripts customizados -->
<script type="text/javascript" src="<?php echo e(asset('front/masks.js')); ?>"></script>
<?php echo $__env->yieldContent('script-bottom'); ?>
<?php /**PATH /opt/bitnami/apache2/htdocs/bohemia/resources/views/layouts/web/footer-script.blade.php ENDPATH**/ ?>