@component('mail::message')
    <h1>Pré-inscrição feita com sucesso!</h1>
    <p> Olá, {{ $name }}. tudo prime? 😉</p>
    <p>Estamos felizes em seu interesse em se credenciar na Prime Drink.
        Recebemos todas as suas informações com sucesso! 🍻
    </p>
    <p>Agora é só aguardar um de nossos especialistas entrar em contato com você e finalizar seu credenciamento! </p>
    *E-mail enviado automático através do sistema.
@endcomponent
