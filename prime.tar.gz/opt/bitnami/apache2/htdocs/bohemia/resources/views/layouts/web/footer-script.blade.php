@yield('script')
<!-- JS -->
<script src="{{asset('front/jquery.min.js')}}"></script>
<script src="{{asset('front/bootstrap.js')}}"></script>
<script src="{{asset('front/retina.js')}}"></script>
<script src="{{asset('front/parallax.js')}}"></script>
<script src="{{asset('front/wow.js')}}"></script>
<script src="{{asset('front/carousel.js')}}"></script>
<script src="{{asset('front/custom.js')}}"></script>
<!-- SLIDER REV -->
<script src="{{asset('front/jquery.themepunch.tools.min.js')}}"></script>
<script src="{{asset('front/jquery.themepunch.revolution.min.js')}}"></script>
<script src="{{asset('front/jquery-ui.js')}}"></script>
<script src="{{asset('front/jquery-ui-timepicker-addon.js')}}"></script>
<script src="{{asset('front/bootstrap-select.js')}}"></script>
<script type="text/javascript">
    function openNav() {
        document.getElementById("mySidenav").style.width = "185px";
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
    }
</script>
<!-- scripts customizados -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.0/jquery.mask.js"></script>
<!-- scripts customizados -->
<script type="text/javascript" src="{{ asset('front/masks.js') }}"></script>
@yield('script-bottom')
